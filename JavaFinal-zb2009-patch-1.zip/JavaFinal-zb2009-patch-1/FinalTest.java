import javax.swing.*;
public class FinalTest extends JFrame
{
    public static void main(String[] args){
        
    }
}

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.ArrayList;
public interface PickRandomQuestions
{
    ConcurrentLinkedQueue<ArrayList<Question>> que = new ConcurrentLinkedQueue<ArrayList<Question>>();
    
    default void startRandom(){
        LoadQuestions ques = new LoadQuestions(que);
        Thread t = new Thread(ques);
        t.start();
    }
    default Question[] pickRandom(){
        int index = 0;
        int count = 0;
        ArrayList<Question> alist = null;
        Question[] questions = null;
        while(count<5){
            alist = que.poll();
            if(alist==null){
                System.out.println("READING WAITING!!!");
                count++;
                try{
                    Thread.sleep(1000);
                } catch(InterruptedException e) {
                    e.printStackTrace();
                }
            } else {
                try{
                    Thread.sleep(1000);
                } catch(InterruptedException e) {
                    e.printStackTrace();
                }
                count = 0;
                questions = new Question[3];
                for(int i=0;i<3;i++){
                    int ran = (int)(Math.random()*alist.size());
                    questions[i] = alist.remove(ran);
                }
                return questions;
            }

        }
        return questions;
    }
}
